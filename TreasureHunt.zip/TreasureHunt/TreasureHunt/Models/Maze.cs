﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TreasureHunt
{
   public class Maze
    {
        public int Size { get; set; }
        public MazeRoom[,] Matrix  { get; set; }
    }
}
