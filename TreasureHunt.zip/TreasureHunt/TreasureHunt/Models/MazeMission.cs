﻿using AtlasCopco.Integration.Maze;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TreasureHunt
{
    public class MazeMission : IMazeIntegration, ITreasureTrapEntranceConfiguration, IDirectionNWallConfiguration
    {
        #region INITIALISATION..
        char[] allDirections = { 'E', 'W', 'N', 'S' };
        bool custom;
        Maze maze = new Maze();
        MazeRoom[,] matrix = null;
        int playerHealthPoints = 0;
        int roomId = 0;
        List<MazeRoom> mazeRooms = null;
        int totalSteps = 0;
        #endregion

        //Parametrised constructor
        public MazeMission(int size, bool customMatrix)
        {
            maze.Size = size;
            matrix = new MazeRoom[size, size];
            playerHealthPoints = size - 1;

            //Sets custom property to true or false, as per the player's choice..
            custom = customMatrix;
        }

        //This method contains the whole logic to play the game
        public bool PlayMaze(int size)
        {
            // Creates a random maze
            BuildMaze(size);

            //Retrives all the maze rooms..
            mazeRooms = GetMazeRooms();

            //Retrieves the entrance room Id
            var entranceRoomId = GetEntranceRoom();

            //Counts the step..
            totalSteps++;

            // Update the visit status of current room..
            UpdateRoomVisitStatus(entranceRoomId);

            // Gets the description of current room..
            var roomDescription = GetDescription(entranceRoomId);
            roomId = entranceRoomId;


            Console.WriteLine(roomDescription);

            //This loop will run until all the health points are consumed..
            while (playerHealthPoints > 0)
            {
                presskey:
                bool arrowKeyPressed = true;
                char direction = new char();
                var key = Console.ReadKey();
                switch (key.Key)
                {
                    case ConsoleKey.LeftArrow:
                        direction = 'W';
                        break;

                    case ConsoleKey.UpArrow:
                        direction = 'N';
                        break;

                    case ConsoleKey.RightArrow:
                        direction = 'E';
                        break;

                    case ConsoleKey.DownArrow:
                        direction = 'S';
                        break;

                    case ConsoleKey.Escape:

                        //User can quit the game by pressing ESCAPE key..
                        Console.WriteLine(Environment.NewLine);
                        Console.WriteLine("***********************************************************");
                        Console.WriteLine("IIT IS SAD..YOU ARE LEAVING THE GAME");
                        Console.WriteLine("Total no. of steps by player: " + totalSteps.ToString());
                        Console.WriteLine("***********************************************************");
                        Environment.Exit(-1);
                        break;

                    default:
                        arrowKeyPressed = false;
                        break;
                }
                if(!arrowKeyPressed)
                {
                    Console.WriteLine(Environment.NewLine);
                    Console.WriteLine("Please press the arrow keys");
                    goto presskey;
                }

                //Gets the roomId of new room after moving left, right, up or down.
                var currentRoomId = GetRoom(roomId, direction);
                if (currentRoomId != -1)
                {
                    //Updates the room visit status by setting IsVisited=true, this status is updated after entering the room..
                    UpdateRoomVisitStatus(currentRoomId.GetValueOrDefault());
                }

                //Returns the description of current room, if CurrentRoomId !=-1. if CurrentRoomId ==-1, that means there is a wall in that direction.
                roomDescription = currentRoomId != -1 ? GetDescription(currentRoomId.GetValueOrDefault()) : "\nThere is a WALL in direction: " + direction;

                //if CurrentRoomId != -1, then currentRoomId is assigned to roomId..
                if (currentRoomId != -1)
                {
                    roomId = currentRoomId.GetValueOrDefault();

                    //Increments the steps...
                    totalSteps++;
                }
                
                // If currentRoomId == -1, that means the room has a wall in specified direction.
                // then it displays the movement instructions..
                if (currentRoomId == -1)
                {
                    roomDescription += "\n\nPress LEFT ARROW key to move left\n";
                    roomDescription += "Press UP ARROW key to move up\n";
                    roomDescription += "Press RIGHT ARROW key to move right\n";
                    roomDescription += "Press DOWN ARROW key to move down\n";
                    roomDescription += "Press ESCAPE key to quit the game\n";
                }



                Console.WriteLine(roomDescription);

                //If current room has treasure, then it displays the total no. of steps by the player. And breaks out of the WHILE loop
                if (HasTreasure(roomId))
                {
                    Console.WriteLine("Total no. of steps by player: " + totalSteps.ToString());
                    Console.WriteLine("*********************************************************");
                    break;
                }
            }

            return true;
        }

        //Method to build the maze of multidimensional matrix
        public void BuildMaze(int size)
        {
            int counter = 0;

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    //Sets Walls to the room in direction where the Index is not within the mentioned position (X and Y axis)..
                    var wallsInDirection = SetWallsToRoom(counter, i, j, size);

                    //Sets the doors in remaining directions of the room..
                    var doorsIndirection = allDirections.Except(wallsInDirection);
                    var room = new MazeRoom();

                    //If the size of matrix is not pre-defined (Matrix size is set by player)
                    if (custom)
                    {
                        room.RoomId = counter;
                        room.Position = new Position { Row = i, Column = j };
                        room.DoorsInDirection = doorsIndirection.ToList();
                        room.WallsInDirection = wallsInDirection;
                    }
                    //If matrix size is pre-defined. As per the guidelines (Matrix size is not to be set by player)..
                    else
                    {
                        room.RoomId = counter;

                        //Sets the Treasure to room with roomId = 5
                        room.BigTreasure = SetTreasure(counter);

                        //Sets the Trap to room with roomId = 1 and roomId = 3
                        room.Trap = SetTrap(counter);

                        //Sets the Entrance to room with roomId = 8
                        room.Entrance = SetEntrance(counter);

                        //Sets the position of room with X and Y co-ordinates..
                        room.Position = new Position { Row = i, Column = j };

                        //Sets the doors and walls to room in different directions..
                        room.DoorsInDirection = doorsIndirection.ToList();
                        room.WallsInDirection = wallsInDirection;
                    }
                    matrix[i, j] = room;
                    counter++;
                }
            }
            maze.Matrix = matrix;

            //If the size of matrix is not pre-defined (Matrix size is set by player)
            if (custom)
            {
                List<List<int>> lstRoomsWithAndWithoutWalls = new List<List<int>>();

                //Sets Walls to the room in direction where the Index not within the mentioned position (X and Y axis)..
                var roomsWithAndWithoutWalls = GetRoomsWithAndWithoutWalls(matrix, lstRoomsWithAndWithoutWalls);

                //Generates random index for entrance room
                var entranceIndex = GenerateRandomNumber(roomsWithAndWithoutWalls[0].Count());
                
                //creates the random entrance room Id 
                var entrance = roomsWithAndWithoutWalls[0][entranceIndex];

                //Removes the entrance room Id from list of rooms with walls..
                roomsWithAndWithoutWalls[0].Remove(entrance);

                //Combines the lists of rooms with walls and list of rooms without walls..
                var totalRoomsWithoutEntrance = roomsWithAndWithoutWalls[0].Concat(roomsWithAndWithoutWalls[1]).ToList();


                List<int> traps = new List<int>();
                var random = new Random();
                for (int i = 0; i < size - 1; i++)
                {
                    //Generates a random index for trap room
                    var trapIndex = random.Next(totalRoomsWithoutEntrance.Count());

                    //Retrives the trap room with above mentioned index..
                    var trap = totalRoomsWithoutEntrance[trapIndex];

                    traps.Add(trap);

                    //Removes the above mentioned trap room from the list of total rooms without entrance..
                    totalRoomsWithoutEntrance.Remove(trap);
                }

                //Generates a random treasure room index
                var treasureIndex = random.Next(totalRoomsWithoutEntrance.Count());

                //Retrieves the treasure room of above mentioned index from list of total rooms without entrance..
                var treasure = totalRoomsWithoutEntrance[treasureIndex];

                //Loops through all the mazeRooms and assigns above captured TREASURE,TRAP and ENTRANCE rooms
                foreach (var mazeRoom in matrix)
                {
                    if (mazeRoom.RoomId == entrance)
                    {
                        mazeRoom.Entrance = true;
                    }
                    else if (traps.Contains(mazeRoom.RoomId))
                    {
                        mazeRoom.Trap = true;
                    }
                    else if (mazeRoom.RoomId == treasure)
                    {
                        mazeRoom.BigTreasure = true;
                    }
                }

                var result = matrix;
            }



        }

        //Retrieves the status of Room, whether it is a TRAP or not..
        public bool CausesInjury(int roomId)
        {
            var room = mazeRooms.Where(x => x.RoomId == roomId).ToList();
            return (room != null && room.Count > 0) ? room[0].Trap : false;
        }

        // Gets the description of current room..
        public string GetDescription(int roomId)
        {
            var mazeRooms = GetMazeRooms();
            var roomInfo = mazeRooms.Where(x => x.RoomId == roomId).ToList();
            var room = roomInfo[0];

            var roomDescription = string.Empty;
            roomDescription += "*********************************************************";

            roomDescription += "\nYou are in room: " + room.RoomId + "\n";

            if (room.Entrance)
            {
                roomDescription += "This is an entrance room\n";
            }
            else if (CausesInjury(room.RoomId))
            {
                // If the current room has TRAP, then 1 Health point is reduced and message is displayed..
                playerHealthPoints -= 1;
                if(playerHealthPoints > 0)
                {
                    roomDescription += "\n###############################################################\n";
                    roomDescription += "\n              UNFORTUNATELY, THIS IS TRAP!!                    \n";
                    roomDescription += "\n         YOU HAVE LOST 1 HEALTH POINT. BE CAREFUL.             \n";
                    roomDescription += "\n###############################################################\n";
                }
                else
                {
                    // If the current room has TRAP and all Health points are consumed, The player loses the game
                    roomDescription += "\n###############################################################\n";
                    roomDescription += "\n                 UNFORTUNATELY, THIS IS TRAP!!                 \n";
                    roomDescription += "\nYOU HAVE LOST ALL YOUR HEALTH POINTS. AND YOU LOST THIS GAME!! \n";
                    roomDescription += "\n                    BETTER LUCK NEXT TIME.                     \n";
                    roomDescription += "\n###############################################################\n";

                    roomDescription += Environment.NewLine;
                    roomDescription += "Total no. of steps by player: " + totalSteps.ToString();
                    roomDescription += "\n*********************************************************\n";
                }
            }
            //Checks whether the current room has TREASURE or not..
            else if (HasTreasure(room.RoomId))
            {
                //If room has TREASURE, Player wins the game and message is displayed
                roomDescription += "\n############################################################\n";
                roomDescription += "\nCONGRATULATIONS!!! YOU FOUND THE TREASURE AND WON THE GAME\n";
                roomDescription += "\n                     BIG PARTY                            \n";
                roomDescription += "\n############################################################\n";
            }
            if (playerHealthPoints > 0 && !HasTreasure(roomId))
            {
                var doors = string.Empty;
                var roomsVisited = string.Empty;
                foreach (var item in room.DoorsInDirection)
                {
                    //Gets the roomId of new room after moving left, right, up or down.
                    var roomInDirection = GetRoom(roomId, item);

                    //Retrieves the status of room, whether it was visited or not
                    var isVisited = IsRoomVisited(roomInDirection.GetValueOrDefault());

                    roomsVisited += isVisited ? item.ToString() + "," : string.Empty;

                    //Retrives the doors in different directions of room..
                    doors += item.ToString() + ",";
                }
                var walls = string.Empty;

                //Loops through the rooms with the list walls in different directions
                foreach (var item in room.WallsInDirection)
                {
                    // retrives the list walls in different directions
                    walls += item.ToString() + ",";
                }
                roomDescription += "\nThere are doors in direction: " + doors.TrimEnd(',') + "\n";
                roomDescription += walls.Count() > 0 ? "There are walls in direction: " + walls.TrimEnd(',') : string.Empty + "\n\n";
                roomDescription += roomsVisited.Count() > 0 ? "\nYou have already visited in direction: " + roomsVisited.TrimEnd(',') : string.Empty + "\n\n";
                roomDescription += "\n\nPress LEFT ARROW key to move left\n";
                roomDescription += "Press UP ARROW key to move up\n";
                roomDescription += "Press RIGHT ARROW key to move right\n";
                roomDescription += "Press DOWN ARROW key to move down\n";
                roomDescription += "Press ESCAPE key to quit the game\n";
                roomDescription += "*********************************************************\n";
            }
            return roomDescription;
        }


        //Retrieves the entrance room Id
        public int GetEntranceRoom()
        {
            //retrieves the roomId of the mazeRoom where Entrance == true
            var entranceRoomId = from MazeRoom item in maze.Matrix
                                 where item.Entrance == true
                                 select item.RoomId;

            return entranceRoomId.ToList()[0];
        }

        //Gets the roomId of new room after moving left, right, up or down..
        public int? GetRoom(int roomId, char direction)
        {
            int newRoomId = 0;

            //Retrieves the list of all maze rooms..
            var mazeRooms = GetMazeRooms();
            
            //retrieves the information of current room.
            var roomInfo = mazeRooms.Where(x => x.RoomId == roomId).ToList();
            if (roomInfo.Count > 0)
            {
                var position = roomInfo[0].Position;
                var row = position.Row;
                var col = position.Column;

                //Retrieves the row and column position after moving to 
                //different directions like north, south, east and west directions
                if (direction == 'W')
                {
                    col -= 1;
                }
                else if (direction == 'E')
                {
                    col += 1;
                }
                else if (direction == 'N')
                {
                    row -= 1;
                }
                else if (direction == 'S')
                {
                    row += 1;
                }

                //Retrieves the new room with updated row (X) and column (Y) co-ordinates..
                var newRoom = mazeRooms.Where(x => x.Position.Column == col && x.Position.Row == row).ToList();

                //If room with position X and Y co-ordinates is not available in the matrix, then -1 is assigned to 
                //new room Id.. 
                //So if newroomId == -1, that means there is a WALL in that direction.
                newRoomId = newRoom.Count > 0 ? newRoom[0].RoomId : -1;
            }
            return newRoomId;
        }

        //Checks whether the current room has TREASURE or not..
        public bool HasTreasure(int roomId)
        {
            var room = mazeRooms.Where(x => x.RoomId == roomId).ToList();
            return room.Count > 0 ? room[0].BigTreasure : false;
        }

        //Sets the Trap to room with roomId = 1 and roomId = 3
        public bool SetTrap(int roomId)
        {
            return (roomId == 1 || roomId == 3) ? true : false;
        }

        //Sets the Treasure to room with roomId = 5
        public bool SetTreasure(int roomId)
        {
            return roomId == 5 ? true : false;
        }

        //Sets the Entrance to room with roomId = 8
        public bool SetEntrance(int roomId)
        {
            return roomId == 8 ? true : false;
        }
        
        //Generates a random number within the max-limit range provided as a parameter..
        public int GenerateRandomNumber(int maxLength)
        {
            return new Random().Next(maxLength);
        }

        //Sets Walls to the room in direction where the Index is not within the mentioned position (X and Y axis)..
        public List<char> SetWallsToRoom(int roomId, int row, int column, int size)
        {
            var wallsInDirection = new List<char>();
            if ((row - 1) < 0)
            {
                wallsInDirection.Add('N');
            }
            if ((row + 1) > (size - 1))
            {
                wallsInDirection.Add('S');
            }
            if ((column - 1) < 0)
            {
                wallsInDirection.Add('W');
            }
            if ((column + 1) > (size - 1))
            {
                wallsInDirection.Add('E');
            }
            return wallsInDirection;
        }

        //Creates two lists: 1st list(rooms with walls) , 2nd list (rooms without walls). Combines these two lists into one list
        public List<List<int>> GetRoomsWithAndWithoutWalls(MazeRoom[,] mazeRooms, List<List<int>> lstRoomsWithAndWithoutWalls)
        {
            List<int> lstRoomsWithWalls = new List<int>();
            List<int> lstRoomsWithoutWalls = new List<int>();
            List<List<int>> RoomsWithAndWithoutWalls = new List<List<int>>();

            foreach (var mazeRoom in mazeRooms)
            {
                if (mazeRoom.WallsInDirection.Count > 0)
                {
                    lstRoomsWithWalls.Add(mazeRoom.RoomId);
                }
                else if (mazeRoom.WallsInDirection.Count == 0)
                {
                    lstRoomsWithoutWalls.Add(mazeRoom.RoomId);
                }
            }
            RoomsWithAndWithoutWalls.Add(lstRoomsWithWalls);
            RoomsWithAndWithoutWalls.Add(lstRoomsWithoutWalls);
            return RoomsWithAndWithoutWalls;
        }

        //Retrieves the list of all maze rooms..
        public List<MazeRoom> GetMazeRooms()
        {
            var mazeRooms = (from MazeRoom item in maze.Matrix
                             select item).ToList();
            return mazeRooms;
        }

        //Updates the room visit status by setting IsVisited=true, this status is updated after entering the room..
        public void UpdateRoomVisitStatus(int roomId)
        {
            var room = mazeRooms.Where(x => x.RoomId == roomId);
            if (room != null && room.Count() > 0)
            {
                room.ToList().ForEach(x => x.IsVisited = true);
            }
        }

        //Retrieves the status of room, whether it was visited or not
        public bool IsRoomVisited(int roomId)
        {
            bool isVisited = false;
            var room = mazeRooms.Where(x => x.RoomId == roomId).Select(x => x.IsVisited);
            if (room != null && room.Count() > 0)
            {
                isVisited = room.ToList()[0];
            }
            return isVisited;
        }

    }
}
