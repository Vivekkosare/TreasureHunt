﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TreasureHunt
{
    public class MazeRoom
    {
        public int RoomId { get; set; }
        public bool Entrance { get; set; }
        public bool Trap { get; set; }
        public bool BigTreasure { get; set; }
        public List<char> DoorsInDirection { get; set; }
        public List<char> WallsInDirection { get; set; }
        public Position Position { get; set; }
        public bool IsVisited { get; set; }
    }
}

