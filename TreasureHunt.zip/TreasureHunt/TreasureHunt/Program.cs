﻿using System;

namespace TreasureHunt
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("* * * * * * * * * * * * * * * * * * * * * *");
            Console.WriteLine("*                                         *");
            Console.WriteLine("*            TREASURE HUNT                *");
            Console.WriteLine("*                                         *");
            Console.WriteLine("* * * * * * * * * * * * * * * * * * * * * *");
            Console.WriteLine("Treasure hunt is a game where you have to find the treasure in a room.");
            Console.WriteLine("You have been provided Health points.");
            Console.WriteLine("Be careful. You may fall into traps.");
            Console.WriteLine("If you fall in a trap, you will loose Health points.");
            Console.WriteLine("If all Health points are consumed, you will lose the game.");
            Console.WriteLine("If you find the treasure without loosing all the health points, you win.");
            Console.WriteLine("Lets Start...");



            a:

            Console.WriteLine(Environment.NewLine);
            Console.WriteLine("Please Enter 1 or 2 to select one of the following options:");
            Console.WriteLine("1. Start the game");
            Console.WriteLine("2. Create a customized matrix to start the game");

            var option = Console.ReadLine();

            if (option != null)
            {
                bool gamePlayed = false;
                try
                {
                    int size = 0;
                    int opt = 0;
                    int num;
                    int matrixNum;
                    bool customMatrix = false;

                    //Checks whether the option is 1 or 2..
                    if (Int32.TryParse(option, out num) && (option == "1" || option == "2"))
                        opt = Convert.ToInt32(option);
                    else
                    {
                        //If any option other 1 or 2 is selected, then game execution again steps back to label:a position
                        goto a;
                    }

                    //Option 1 refers to selection of predefined mazeRoom matrix (with pre-defined TRAP and TREASURES)
                    if (opt == 1)
                    {
                        var mazeMission = new MazeMission(3, customMatrix);

                        //Calls the PlayMaze method, which creates a maze and lets user play the game..
                        gamePlayed = mazeMission.PlayMaze(3);
                    }
                    else
                    {
                        //This execution runs when players selects to create a customized matrix..
                        matrixSize:
                        Console.WriteLine(Environment.NewLine);
                        Console.WriteLine("Enter the matix size between 1 to 100: ");

                        var sizeInput = Console.ReadLine();

                        if (Int32.TryParse(sizeInput, out matrixNum))
                        {
                            int matrixSize = Convert.ToInt32(sizeInput);

                            //The custom matrix size should be within the range 1 to 100..
                            if (matrixSize > 0 && matrixSize <= 100)
                            {
                                size = matrixSize;
                            }
                            else
                            {
                                //This message is printed, when the user input is not within the range 1-100.
                                Console.WriteLine("Invalid Input");
                                goto matrixSize;
                            }
                        }
                        else
                        {
                            //execution steps back to label: matrixSize, if the user input is invalid
                            goto matrixSize;
                        }


                        customMatrix = true;
                        var mazeMission = new MazeMission(size, customMatrix);

                        //Calls the PlayMaze method, which creates a maze and lets user play the game..
                        gamePlayed = mazeMission.PlayMaze(size);
                    }
                    Console.WriteLine(Environment.NewLine);

                    //Player is asked, whether players wants to play the game again or not?..
                    b:
                    Console.WriteLine("Do you want to play the game again? Press Y or N");
                    var response = Console.ReadLine();

                    //THis option lets the PLAYER play the game again..
                    if (response.ToLower() == "y")
                    {
                        Console.WriteLine(Environment.NewLine);
                        goto a;
                    }
                    else if (response.ToLower() == "n")
                    {
                        //Player will exit the game by pressing key 'N' or 'n'
                        Environment.Exit(-1);
                    }
                    else
                    {
                        //Execution steps back to label:b, if user input is invalid..
                        Console.WriteLine("Please press Y or N");
                        goto b;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }





        }
    }
}
