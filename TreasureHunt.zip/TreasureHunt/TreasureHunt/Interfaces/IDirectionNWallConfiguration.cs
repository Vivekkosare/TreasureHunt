﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TreasureHunt
{
    interface IDirectionNWallConfiguration
    {
        List<char> SetWallsToRoom(int roomId, int row, int column, int size);
        List<List<int>> GetRoomsWithAndWithoutWalls(MazeRoom[,] mazeRooms, List<List<int>> lstRoomsWithAndWithoutWalls);
        List<MazeRoom> GetMazeRooms();
        void UpdateRoomVisitStatus(int roomId);
        bool IsRoomVisited(int roomId);
    }
}
