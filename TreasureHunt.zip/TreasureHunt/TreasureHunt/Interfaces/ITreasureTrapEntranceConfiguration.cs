﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TreasureHunt
{
    interface ITreasureTrapEntranceConfiguration
    {
        bool SetTrap(int roomId);
        bool SetTreasure(int roomId);
        bool SetEntrance(int roomId);
        int GenerateRandomNumber(int maxLength);
    }
}
